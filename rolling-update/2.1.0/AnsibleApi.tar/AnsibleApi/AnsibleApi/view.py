# -*- coding: UTF-8 -*- 
from django.http import HttpResponse
from . import ansible
 
def install(request):
    host = request.GET.get('host','')
    user = request.GET.get('user','')
    port = request.GET.get('port','')
    passwd = request.GET.get('passwd','')
    masterIp = request.GET.get('masterIp','')
    harborIp = request.GET.get('harborIp','')
    if host.strip()=="":
        data = '{"code": "5000", "msg": "host不能为空!"}'
        return HttpResponse(data)
    if user.strip()=="":
        data = '{"code": "5000", "msg": "user不能为空!"}'
        return HttpResponse(data)
    if user.strip()=="":
        data = '{"code": "5000", "msg": "port不能为空!"}'
        return HttpResponse(data)
    if passwd.strip()=="":
        data = '{"code": "5000", "msg": "密码不能为空!"}'
        return HttpResponse(data)
    if masterIp.strip()=="":
        data = '{"code": "5000", "msg":"masterIp不能为空!"}'
        return HttpResponse(data)
    if harborIp.strip()=="":
        data = '{"code": "5000", "msg": "harborIp不能为空!"}'
        return HttpResponse(data)
    if ansible.run_installNode(host, user, port,passwd, harborIp, masterIp) == False:
        data = '{"code": "5000", "msg": "上线失败!"}'
        return HttpResponse(data)
    data = '{"code": "1000", "msg": "上线成功!"}'
    return HttpResponse(data)

def un_install(request):
    nodeName = request.GET.get('host','')
    nodeIp = request.GET.get('hostIp','')
    user = request.GET.get('user','')
    port = request.GET.get('port','')
    passwd = request.GET.get('passwd','')
    masterIp = request.GET.get('masterIp','')
    token = request.GET.get('token','')
    if nodeName.strip()=="":
        data = '{"code": "5000", "msg": "nodeName不能为空!"}'
        return HttpResponse(data)
    if nodeIp.strip()=="":
        data = '{"code": "5000", "msg": "nodeIp不能为空!"}'
        return HttpResponse(data)
    if user.strip()=="":
        data = '{"code": "5000", "msg": "user不能为空!"}'
        return HttpResponse(data)
    if port.strip()=="":
        data = '{"code": "5000", "msg": "port不能为空!"}'
        return HttpResponse(data)
    if passwd.strip()=="":
        data = '{"code": "5000", "msg": "密码不能为空!"}'
        return HttpResponse(data)
    if masterIp.strip()=="":
        data = '{"code": "5000", "msg":"masterIp不能为空!"}'
        return HttpResponse(data)
    if token.strip()=="":
        data = '{"code": "5000", "msg":"token不能为空!"}'
        return HttpResponse(data)
    if ansible.run_uninstallNode(nodeName, nodeIp, user, port, passwd, masterIp, token) == False:
        data = '{"code": "5000", "msg":"下线失败!"}'
        return HttpResponse(data) 
    data = '{"code": "1000", "msg": "下线成功!"}'
    return HttpResponse(data)

