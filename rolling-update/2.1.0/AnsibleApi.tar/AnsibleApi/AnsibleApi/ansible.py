#!/usr/bin/python

from installprogress.models import installprogress
from . import utils
from . import uninstall
import os
import pexpect

hostsfile="/etc/ansible/hosts"
ntpIp='10.10.102.52'
ntpInstall='true'
#run_installNode('10.10.101.163', 'test', '14816', 'Ab@123', '10.10.103.29', '10.10.103.30')

def run_installNode(host, user, port, passwds, harborIp, masterIp):
  if utils.find_word(hostsfile, host) == False:
    utils.write_word(hostsfile, host+' '+'ansible_ssh_port=' + port + ' ' + 'ansible_ssh_user=' + user + ' ' + 'ansible_ssh_pass=' + passwds + ' ' + 'ansible_sudo_pass=' + passwds + ' ' + 'ansible_become_pass='+ passwds + ' host_key_checking=False')
#    installprogress.objects.create(name=host, progress=0)
#  hostname_cmd = 'ansible '+host+' -m command -a "echo '+host+' > /etc/hostname" -u '+user+' -k '
#  if run_ansible_cmd(host, passwds, hostname_cmd, 2) == False:
#    return False
#  hn_cmd = 'ansible '+host+' -m command -a "hostname '+host+'" -u '+user+' -k '
#  if run_ansible_cmd(host, passwds, hn_cmd, 3) == False:
#    return False

  print "1"
  #copy_test_cmd = './copy.sh '+host+' '+port+' '+user+' '+passwds + ' ~/k8s-upgrade-deploy/deploy-k8s.tar.gz /home/'
  #if run_ansible_c(passwds, copy_test_cmd) == False:
    #return False
  copy_cmd = 'ansible '+host+' -m copy -a "src=~/k8s-upgrade-deploy/deploy-k8s.tar.gz dest=/home/'+user+' owner='+user+' group='+user+' mode=0755" -u '+user+' -k '
  if run_ansible_cmd(host, passwds, copy_cmd, 5) == False:
    return False

  print "2"
  copy_docker_cmd = 'ansible '+host+' -m copy -a "src=~/k8s-upgrade-deploy/deploy-docker.tar.gz dest=/home/'+user+' owner='+user+' group='+user+' mode=0755" -u '+user+' -k '
  if run_ansible_cmd(host, passwds, copy_docker_cmd, 10) == False:
    return False

  print "3"
  copy_ntp_cmd = 'ansible '+host+' -m copy -a "src=~/k8s-upgrade-deploy/deploy-ntp.tar.gz dest=/home/'+user+' owner='+user+' group='+user+' mode=0755" -u '+user+' -k '
  if run_ansible_cmd(host, passwds, copy_ntp_cmd, 15) == False:
    return False

  print "4"
  tar_cmd = 'ansible '+host+' -m command -a "tar xf deploy-k8s.tar.gz -C ~/"  -u '+user+' -k '
  if run_ansible_cmd(host, passwds, tar_cmd, 20) == False:
    return False

  print "5"
  tar_docker_cmd = 'ansible '+host+' -m command -a "tar xf deploy-docker.tar.gz -C ~/"  -u '+user+' -k '
  if run_ansible_cmd(host, passwds, tar_docker_cmd, 25) == False:
    return False

  print "6"
  tar_ntp_cmd = 'ansible '+host+' -m command -a "tar xf deploy-ntp.tar.gz -C ~/"  -u '+user+' -k '
  if run_ansible_cmd(host, passwds, tar_ntp_cmd, 30) == False:
    return False
 
  print "7"
  docker_cmd = 'ansible '+host+' -m command -a "/home/'+user+'/deploy-docker/install.sh '+harborIp+'" -u '+user+' --sudo'
  if run_ansible_install_cmd(host, docker_cmd, 35) == True:
    print "sucess" 
  else: 
    print "fail"
  
  print "8"
  kubeadm_cmd = 'ansible '+host+'  -m command -a "/home/'+user+'/deploy-k8s/install-kubeadm.sh '+harborIp+' '+masterIp+'" -u '+user+' --sudo '
  if run_ansible_install_cmd(host, kubeadm_cmd, 40) == True:
    print "sucess"
  else:
    print "fail"
 
  print "9"
  node_cmd = 'ansible '+host+'  -m command -a "/home/'+user+'/deploy-k8s/install-node-sub.sh '+harborIp+' '+masterIp+' '+ntpIp+' '+ntpInstall+'" -u '+user+' --sudo '
  if run_ansible_install_cmd(host, node_cmd, 45) == True:
    print "sucess"
  else:
    print "fail"

  print "10"
  reboot_cmd = 'ansible '+host+'  -m command -a "systemctl reboot -i" -u '+user+' --sudo '
  if run_ansible_install_cmd(host, reboot_cmd, 50) == True:
    print "sucess"
  else:
    print "fail"
 
  return True

def run_uninstallNode(nodeName, nodeIp, user, port, passwds, masterIp, token):
  if utils.find_word(hostsfile ,nodeIp) == False:
    utils.write_word(hostsfile, nodeIp + ' ' +'ansible_ssh_port=' + port + ' ' + 'ansible_ssh_user=' + user + ' ' + 'ansible_ssh_pass=' + passwds + ' ' + 'ansible_sudo_pass=' + passwds + ' ' + 'ansible_become_pass='+ passwds + ' host_key_checking=False') 
#  if utils.find_word(hostsfile ,masterIp) == False:
#    utils.write_word(hostsfile, masterIp)
  
#  if token.strip()=="":
#    if uninstall.run_cordon_node_http(masterIp, nodeIp) == False:
#      return False
#    if uninstall.run_drain_node_http(masterIp, nodeIp) == False:
#      return False
#  else:
#    if uninstall.run_cordon_node_https(masterIp, nodeIp, token) == False:
#      return False
#    if uninstall.run_drain_node_https(masterIp, nodeIp, token) == False:
#      return False

  node_cmd = 'ansible '+nodeIp+' -m command -a "systemctl stop kubelet.service" -u '+user+' --sudo '
  if run_ansible_delete_cmd(passwds, node_cmd) == False:
    return False

#  node_name = $(/usr/bin/kubectl get node --server=https://'+masterIp+':6443 --token='+token +' --insecure-skip-tls-verify=true |awk 'NR==2 {print $1 }') 
#  print "$node_name" 
#  if run_ansible_delete_cmd(passwds, cmd_name)==False:
    return False

  delete_cmd = '/usr/bin/kubectl delete node '+nodeName+' --server=https://'+masterIp+':6443 --token='+token+' --insecure-skip-tls-verify=true'
  if run_ansible_c(passwds, delete_cmd) == False:
    return False

  reset_cmd = 'ansible '+nodeIp+'  -m command -a "kubeadm reset" -u '+user+' --sudo '
  if run_ansible_delete_cmd(passwds, reset_cmd) == False:
    return False
  
  reboot_cmd = 'ansible '+nodeIp+'  -m command -a "reboot" -u '+user+' --sudo '
  if run_ansible_delete_cmd(passwds, reboot_cmd) == False:
    return False

  return True

def run_ansible_cmd(host,passwds,cmd_name,pro):
  child = pexpect.spawn(cmd_name)
  child.expect(':')
  child.sendline(passwds)
  child.expect(pexpect.EOF, timeout=None)
  print child.before
  installprogress.objects.filter(name=host).update(progress=pro)
  return True

def run_ansible_install_cmd(host,cmd_name,pro):
  child = pexpect.spawn(cmd_name)
  child.expect(pexpect.EOF, timeout=None)
  print child.before
  installprogress.objects.filter(name=host).update(progress=pro)
  return True

def run_ansible_uncmd(passwds,cmd_name):
  child = pexpect.spawn(cmd_name)
  child.expect(':')
  child.sendline(passwds)
  child.expect(pexpect.EOF, timeout=None)
  print child.before
  return True

def run_ansible_delete_cmd(passwds,cmd_name):
  child = pexpect.spawn(cmd_name)
  child.expect(pexpect.EOF, timeout=None)
  print child.before
  return True

def run_ansible_c(passwd,cmd_name):
  child = pexpect.spawn(cmd_name)
  #child.expect(':')
  child.expect(pexpect.EOF, timeout=None)
  print child.before
  return True

