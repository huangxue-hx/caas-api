from django.db import models
 
class installprogress(models.Model):
    name = models.CharField(max_length=30)
    progress = models.IntegerField()
