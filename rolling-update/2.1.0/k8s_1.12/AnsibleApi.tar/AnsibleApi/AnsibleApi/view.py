# -*- coding: UTF-8 -*- 
from django.http import HttpResponse
from . import ansible
 
def install(request):
    host = request.GET.get('host','')
    user = request.GET.get('user','')
    passwd = request.GET.get('passwd','')
    masterIp = request.GET.get('masterIp','')
    harborIp = request.GET.get('harborIp','')
    print harborIp
    if host.strip()=="":
        data = '{"code": "5000", "msg": "host不能为空!"}'
        return HttpResponse(data)
    if user.strip()=="":
        data = '{"code": "5000", "msg": "user不能为空!"}'
        return HttpResponse(data)
    if passwd.strip()=="":
        data = '{"code": "5000", "msg": "密码不能为空!"}'
        return HttpResponse(data)
    if masterIp.strip()=="":
        data = '{"code": "5000", "msg":"masterIp不能为空!"}'
        return HttpResponse(data)
    if harborIp.strip()=="":
        data = '{"code": "5000", "msg": "harborIp不能为空!"}'
        return HttpResponse(data)
    if ansible.run_installNode(host, user, passwd, harborIp, masterIp) == False:
        data = '{"code": "5000", "msg": "上线失败!"}'
        return HttpResponse(data)
    data = '{"code": "1000", "msg": "上线成功!"}'
    return HttpResponse(data)

def un_install(request):
    host = request.GET.get('host','')
    hostName = request.GET.get('hostName','')
    user = request.GET.get('user','')
    passwd = request.GET.get('passwd','')
    masterIp = request.GET.get('masterIp','')
    token = request.GET.get('token','')
    if host.strip()=="":
        data = '{"code": "5000", "msg": "user不能为空!"}'
        return HttpResponse(data)
    if user.strip()=="":
        data = '{"code": "5000", "msg": "user不能为空!"}'
        return HttpResponse(data)
    if passwd.strip()=="":
        data = '{"code": "5000", "msg": "密码不能为空!"}'
        return HttpResponse(data)
    if masterIp.strip()=="":
        data = '{"code": "5000", "msg":"masterIp不能为空!"}'
        return HttpResponse(data)
    if token.strip()=="":
        data = '{"code": "5000", "msg":"token不能为空!"}'
        return HttpResponse(data)
    if ansible.run_uninstallNode(host, hostName,  user, passwd, masterIp, token) == False:
        data = '{"code": "5000", "msg":"下线失败!"}'
        return HttpResponse(data)
    data = '{"code": "1000", "msg": "下线成功!"}'
    return HttpResponse(data)

