#!/usr/bin/python
import json
from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.executor.playbook_executor import PlaybookExecutor
from installprogress.models import installprogress
from . import utils
from . import uninstall

loader = DataLoader()
variable_manager = VariableManager()
inventory = Inventory(loader=loader, variable_manager=variable_manager)
variable_manager.set_inventory(inventory)
hostsfile="/etc/ansible/hosts"

class Options(object):

  def __init__(self):
    self.connection = "local"
    self.forks = 1
    self.check = False

  def __getattr__(self, name):
    return None

options = Options()

def run_adhoc(host, user, passwds, module, args):
  variable_manager.extra_vars={"ansible_ssh_user":user , "ansible_ssh_pass":passwds}
  play_source = {"name":"Ansible Ad-Hos","hosts":host,"gather_facts":"no","tasks":[{"action":{"module":module,"args":args}}]}
  play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
  tqm = None
  try:
    tqm = TaskQueueManager(
    inventory=inventory,
    variable_manager=variable_manager,
    loader=loader,
    options=options,
    passwords=None,
    stdout_callback='minimal',
    run_tree=False,
    )
    result = tqm.run(play)
    print result
  finally:
    if tqm is not None:
      tqm.cleanup()

def run_installNode(host, user, passwds, harborIp, masterIp):
  if utils.find_word(hostsfile ,host) == False:
    utils.write_word(hostsfile, host)
    installprogress.objects.create(name=host, progress=0)
  installprogress.objects.filter(name=host).update(progress=0)
  run_adhoc(host, user, passwds, "copy", "src=/root/deploy-k8s dest=/root owner=root group=root mode=0755")
  installprogress.objects.filter(name=host).update(progress=5)
  #run_adhoc(host, user, passwds,"command","tar -zxvf /data/node-up-down.tar.gz -C /root")
  installprogress.objects.filter(name=host).update(progress=8)
  run_adhoc(host, user, passwds,"command","/root/deploy-k8s/install-node.sh "+harborIp+" "+masterIp)
  installprogress.objects.filter(name=host).update(progress=90)
  #run_adhoc(host, user, passwds,"command","rm -rf ~/deploy-k8s")
  installprogress.objects.filter(name=host).update(progress=95)
  #run_adhoc(host, user, passwds,"command","rm -f /data/node-up-down.tar.gz")
  installprogress.objects.filter(name=host).update(progress=100)

def run_uninstallNode(nodeIp, user, passwds, masterIp, token):
  if utils.find_word(hostsfile ,host) == False:
    utils.write_word(hostsfile, host)
  if token.strip()=="":
    if uninstall.run_cordon_node_http(masterIp, nodeIp) == False:
      return False
    if uninstall.run_drain_node_http(masterIp, nodeIp) == False:
      return False
  else:
    if uninstall.run_cordon_node_https(masterIp, nodeIp, token) == False:
      return False
    if uninstall.run_drain_node_https(masterIp, nodeIp, token) == False:
      return False
  run_adhoc(host, user, passwds,"command","systemctl stop kubelet.service")

  
def run_test(host, user, passwds, harborIp, masterIp):
  if utils.find_word(hostsfile ,host) == False:
    utils.write_word(hostsfile, host)
  result=run_adhoc(host,user,passwds,"shell","ls -al /root")
  print result 

