#!/usr/bin/python

from installprogress.models import installprogress
from . import utils
from . import uninstall
import os
import pexpect

hostsfile="/etc/ansible/hosts"
ntpIp="127.0.0.1"

def run_installNode(host, user, passwds, harborIp, masterIp):
#  print 1111
  if utils.find_word(hostsfile ,host) == False:
    utils.write_word(hostsfile, host)
#    installprogress.objects.create(name=host, progress=0)
#  hostname_cmd = 'ansible '+host+' -m command -a "echo '+host+' > /etc/hostname" -u '+user+' -k '
#  if run_ansible_cmd(host, passwds, hostname_cmd, 2) == False:
#    return False
#  hn_cmd = 'ansible '+host+' -m command -a "hostname '+host+'" -u '+user+' -k '
#  if run_ansible_cmd(host, passwds, hn_cmd, 3) == False:
#    return False
  copy_cmd = 'ansible '+host+' -m copy -a "src=~/k8s-upgrade-deploy/deploy-k8s.tar.gz dest=~/ owner=root group=root mode=0755" -u '+user+' -k '
  if run_ansible_cmd(host, passwds, copy_cmd, 5) == False:
    return False
  tar_cmd = 'ansible '+host+' -m command -a "tar -zxf ~/deploy-k8s.tar.gz -C ~/"  -u '+user+' -k '
  if run_ansible_cmd(host, passwds, tar_cmd, 10) == False:
    return False
  copy_docker_cmd = 'ansible '+host+' -m copy -a "src=~/k8s-upgrade-deploy/deploy-docker.tar.gz dest=~/ owner=root group=root mode=0755" -u '+user+' -k '
  if run_ansible_cmd(host, passwds, copy_docker_cmd, 15) == False:
    return False
  tar_docker_cmd = 'ansible '+host+' -m command -a "tar -zxf ~/deploy-docker.tar.gz -C ~/"  -u '+user+' -k '
  if run_ansible_cmd(host, passwds, tar_docker_cmd, 20) == False:
    return False
  copy_ntp_cmd = 'ansible '+host+' -m copy -a "src=~/k8s-upgrade-deploy/deploy-ntp.tar.gz dest=~/ owner=root group=root mode=0755" -u '+user+' -k '
  if run_ansible_cmd(host, passwds, copy_ntp_cmd, 30) == False:
    return False
  tar_ntp_cmd = 'ansible '+host+' -m command -a "tar -zxf ~/deploy-ntp.tar.gz -C ~/"  -u '+user+' -k '
  if run_ansible_cmd(host, passwds, tar_ntp_cmd, 40) == False:
    return False
  docker_cmd = 'ansible '+host+'  -m command -a "~/deploy-docker/install.sh '+harborIp+' '+"k8s"+' " -u '+user+' -k '
  print(docker_cmd)
  if run_ansible_cmd(host, passwds, docker_cmd, 50) == False:
    return False
#  copy_node_sub_cmd = 'ansible '+host+' -m copy -a "src=~/k8s-upgrade-deploy/deploy-k8s/install-node-sub.sh dest=~/deploy-k8s owner=root group=root mode=0755" -u '+user+' -k '
#  if run_ansible_cmd(host, passwds, copy_node_sub_cmd, 72) == False:
#    return False
  node_cmd = 'ansible '+host+'  -m command -a "~/deploy-k8s/install-node-sub.sh '+harborIp+' '+masterIp+' '+ntpIp+'" -u '+user+' -k '
  if run_ansible_cmd(host, passwds, node_cmd, 90) == False:
    return False
#  reboot_cmd = 'ansible '+host+'  -m command -a "reboot" -u '+user+' -k '
#  if run_ansible_cmd(host, passwds, reboot_cmd, 99) == False:
#    return False
#  fluend_lable_cmd = 'ansible '+masterIp+'  -m command -a "/usr/bin/kubectl label node '+host+' alpha.kubernetes.io/fluentd-ds-ready=true --server=https://'+masterIp+':6443 --token='+"8358ba.70fdd01e8e5eb18b" +' --insecure-skip-tls-verify=true" -u '+user+' -k '
#  if run_ansible_uncmd(passwds, fluend_lable_cmd) == False:
#    return False
  return True

def run_uninstallNode(nodeIp, hostName, user, passwds, masterIp, token):
  if utils.find_word(hostsfile ,nodeIp) == False:
    utils.write_word(hostsfile, nodeIp)
  if utils.find_word(hostsfile ,masterIp) == False:
    utils.write_word(hostsfile, masterIp)
  #if token.strip()=="":
  #  if uninstall.run_cordon_node_http(masterIp, nodeIp) == False:
  #    return False
  #  if uninstall.run_drain_node_http(masterIp, nodeIp) == False:
  #    return False
  #else:
  #  if uninstall.run_cordon_node_https(masterIp, nodeIp, token) == False:
  #    return False
  #  if uninstall.run_drain_node_https(masterIp, nodeIp, token) == False:
  #    return False
  node_cmd = 'ansible '+nodeIp+'  -m command -a "systemctl stop kubelet.service" -u '+user+' -k '
  if run_ansible_uncmd(passwds, node_cmd) == False:
    return False
  reset_cmd = 'ansible '+nodeIp+'  -m command -a "kubeadm reset -f" -u '+user+' -k '
  if run_ansible_uncmd(passwds, reset_cmd) == False:
    return False
  delete_cmd = 'ansible '+masterIp+'  -m command -a "/usr/bin/kubectl delete node '+hostName+' --server=https://'+masterIp+':6443 --token='+token +' --insecure-skip-tls-verify=true" -u '+user+' -k '
  if run_ansible_uncmd(passwds, delete_cmd) == False:
    return False
  reboot_cmd = 'ansible '+nodeIp+'  -m command -a "reboot" -u '+user+' -k '
  if run_ansible_uncmd(passwds, reboot_cmd) == False:
    return False
  return True

def run_ansible_cmd(host,passwds,cmd_name,pro):
  child = pexpect.spawn(cmd_name)
  child.expect(':')
  child.sendline(passwds)
  child.expect(pexpect.EOF, timeout=None)
  print child.before
  installprogress.objects.filter(name=host).update(progress=pro)
  return True

def run_ansible_uncmd(passwds,cmd_name):
  child = pexpect.spawn(cmd_name)
  child.expect(':')
  child.sendline(passwds)
  child.expect(pexpect.EOF, timeout=None)
  print child.before
  return True

