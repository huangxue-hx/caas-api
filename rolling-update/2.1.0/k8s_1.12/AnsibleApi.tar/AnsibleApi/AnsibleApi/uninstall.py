#!/usr/bin/python
import os

def run_cmd(cmd):
  status = os.system(cmd)
  return status

def run_cordon_node_https(masterIp, nodeIp, token):
  status = run_cmd("/usr/bin/kubectl cordon "+nodeIp+" --server=https://"+masterIp+":6443 " +" --token="+token +" --insecure-skip-tls-verify=true")
  if status == 0:
    return True
  return False
  
def run_cordon_node_http(masterIp, nodeIp):
  status = run_cmd("/usr/bin/kubectl cordon "+nodeIp+" --server=http://"+masterIp+":8080 ")
  if status == 0:
    return True
  return False

def run_drain_node_https(masterIp, nodeIp, token):
  status = run_cmd("/usr/bin/kubectl drain "+nodeIp+" --ignore-daemonsets=true --delete-local-data=true --force=true --timeout=600s "+" --server=https://"+masterIp+":6443 " +" --token="+token +" --insecure-skip-tls-verify=true")
  if status == 0:
    return True
  return False

def run_drain_node_http(masterIp, nodeIp):
  status = run_cmd("/usr/bin/kubectl drain "+nodeIp+" --ignore-daemonsets=true --delete-local-data=true --force=true --timeout=600s "+" --server=http://"+masterIp+":8080 ")
  if status == 0:
    return True
  return False

def run_delete_node_https(masterIp, nodeIp, token):
  print "/usr/bin/kubectl delete node "+nodeIp+" --server=https://"+masterIp+":6443 " +" --token="+token +" --insecure-skip-tls-verify=true"
  status = run_cmd("/usr/bin/kubectl delete node "+nodeIp+" --server=https://"+masterIp+":6443 " +" --token="+token +" --insecure-skip-tls-verify=true")
  if status == 0:
    return True
  return False

def run_delete_node_http(masterIp, nodeIp):
  status = run_cmd("/usr/bin/kubectl delete node "+nodeIp+" --server=http://"+masterIp+":8080 ")
  if status == 0:
    return True
  return False
