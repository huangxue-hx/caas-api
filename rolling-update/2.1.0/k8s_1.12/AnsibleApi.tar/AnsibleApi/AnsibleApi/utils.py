#!/usr/bin/python

def find_word(filename,word):
    flag = False
    with open(filename, 'r') as f:
        for l in f.readlines():
              if word in l:
                  flag = True
                  break
    print flag
    return flag

def write_word(filename,word):
    flag = False
    f=open(filename, 'a')
    f.write('\n'+word)
    f.close()
